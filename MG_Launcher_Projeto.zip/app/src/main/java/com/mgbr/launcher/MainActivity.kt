package com.mgbr.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 29, 20)
    private val green = Color.rgb(77, 190, 91)
    private val pale = Color.rgb(223, 245, 222)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(21, 53, 31)
        window.navigationBarColor = Color.rgb(16, 42, 25)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(page)

        page.addView(label("MG", 18, green, true).apply { letterSpacing = 0.18f })
        page.addView(label("LAUNCHER", 34, Color.WHITE, true))
        page.addView(label("Seu mundo começa aqui.", 16, pale, false).apply {
            setPadding(0, dp(2), 0, dp(22))
        })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(24), dp(18), dp(24))
            background = rounded(Color.rgb(30, 64, 39), 22)
        }
        hero.addView(label("▦", 54, green, true))
        hero.addView(label("MINECRAFT BEDROCK", 20, Color.WHITE, true))
        hero.addView(label("Launcher independente para Android", 13, pale, false))
        page.addView(hero, params(match(), wrap()).apply { bottomMargin = dp(22) })

        page.addView(button("▶   ABRIR MINECRAFT", green, Color.rgb(10, 35, 16)) {
            openMinecraft()
        }, params(match(), dp(58)).apply { bottomMargin = dp(12) })

        page.addView(button("📁   ESCOLHER ARQUIVO .MCPACK / .MCWORLD", Color.rgb(37, 55, 42), Color.WHITE) {
            chooseFile()
        }, params(match(), dp(56)).apply { bottomMargin = dp(12) })

        page.addView(button("⚙   CONFIGURAÇÕES DO APLICATIVO", Color.rgb(37, 55, 42), Color.WHITE) {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Não foi possível abrir as configurações.", Toast.LENGTH_SHORT).show()
            }
        }, params(match(), dp(56)).apply { bottomMargin = dp(22) })

        val note = label(
            "IMPORTANTE\nEste launcher abre o Minecraft oficial instalado no aparelho e permite escolher arquivos para importação. Ele não baixa o jogo, não desbloqueia versões pagas e não altera arquivos protegidos do Minecraft.",
            13, Color.rgb(190, 207, 191), false
        )
        note.setPadding(dp(14), dp(14), dp(14), dp(14))
        note.background = rounded(Color.rgb(25, 43, 30), 14)
        page.addView(note, params(match(), wrap()).apply { bottomMargin = dp(18) })
        page.addView(label("MG Launcher • versão 1.0", 12, Color.rgb(132, 160, 136), false).apply {
            gravity = Gravity.CENTER
        })

        setContentView(scroll)
    }

    private fun openMinecraft() {
        val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Minecraft Bedrock não foi encontrado. Instale/abra o jogo oficial primeiro.", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream",
                "application/zip",
                "application/x-minecraft-pack"
            ))
        }
        try {
            startActivityForResult(intent, 42)
            Toast.makeText(this, "Escolha um arquivo .mcpack ou .mcworld. Depois, abra-o com o Minecraft se o Android oferecer essa opção.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            gravity = Gravity.CENTER
        }

    private fun button(text: String, color: Int, textColor: Int, action: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(textColor)
            background = rounded(color, 16)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun wrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun params(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
}
